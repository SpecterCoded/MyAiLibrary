#property strict
#property version   "2.00"
#property description "Journalit private local trade, account and chart exporter for MetaTrader 4"

input int  ExportIntervalSeconds = 5;
input bool CaptureEntryScreenshots = true;
input bool CaptureExitScreenshots = true;
input int  ScreenshotWidth = 1600;
input int  ScreenshotHeight = 900;
input bool ShowTradeMarkers = true;

datetime ExpertStartedAt = 0;
bool EffectiveCaptureEntry = true;
bool EffectiveCaptureExit = true;
bool EffectiveShowMarkers = true;
int EffectiveWidth = 1600;
int EffectiveHeight = 900;

string Int64ToString(long value) { return StringFormat("%I64d", value); }
string CleanText(string value)
{
   StringReplace(value,"\t"," "); StringReplace(value,"\r"," ");
   StringReplace(value,"\n"," "); return value;
}
string SafeFilePart(string value)
{
   string result=value;
   StringReplace(result,"\\","_"); StringReplace(result,"/","_");
   StringReplace(result,":","_"); StringReplace(result,"*","_");
   StringReplace(result,"?","_"); StringReplace(result,"\"","_");
   StringReplace(result,"<","_"); StringReplace(result,">","_");
   StringReplace(result,"|","_"); StringReplace(result," ","_");
   return result;
}
string SnapshotFileName()
{
   return "Journalit\\Journalit_MT4_"+SafeFilePart(AccountServer())+"_"+
      IntegerToString(AccountNumber())+"_"+Int64ToString(ChartID())+".tsv";
}
string AccountMode() { return IsDemo() ? "demo" : "real"; }
string DirectionForType(int type) { return type==OP_SELL ? "short":"long"; }
bool IsMarketOrder(int type) { return type==OP_BUY || type==OP_SELL; }
string TimeframeName() { return IntegerToString(Period()); }
void LoadJournalitSettings()
{
   EffectiveCaptureEntry=CaptureEntryScreenshots;
   EffectiveCaptureExit=CaptureExitScreenshots;
   EffectiveWidth=ScreenshotWidth;
   EffectiveHeight=ScreenshotHeight;
   EffectiveShowMarkers=ShowTradeMarkers;
   int handle=FileOpen("Journalit\\Journalit_settings.tsv",
      FILE_READ|FILE_CSV|FILE_COMMON|FILE_ANSI,'\t');
   if(handle==INVALID_HANDLE) return;
   string header=FileReadString(handle);
   if(header=="JOURNALIT_MT_SETTINGS_V1" && !FileIsEnding(handle))
   {
      string row=FileReadString(handle);
      if(row=="CONFIG")
      {
         EffectiveCaptureEntry=FileReadString(handle)=="1";
         EffectiveCaptureExit=FileReadString(handle)=="1";
         EffectiveWidth=(int)StringToInteger(FileReadString(handle));
         EffectiveHeight=(int)StringToInteger(FileReadString(handle));
         EffectiveShowMarkers=FileReadString(handle)=="1";
      }
   }
   FileClose(handle);
}
string ShotKey(int ticket,string kind)
{
   return "JournalitShot4_"+IntegerToString(AccountNumber())+"_"+
      IntegerToString(ticket)+"_"+kind;
}
string ScreenshotName(int ticket,string kind)
{
   return "Journalit_MT4_"+IntegerToString(AccountNumber())+"_"+
      IntegerToString(ticket)+"_"+kind+".png";
}

void AddMarker(string name,int type,datetime markerTime,double price,
   color markerColor,string label)
{
   if(!EffectiveShowMarkers || price<=0) return;
   if(ObjectCreate(0,name,type,0,markerTime,price))
   {
      ObjectSetInteger(0,name,OBJPROP_COLOR,markerColor);
      ObjectSetInteger(0,name,OBJPROP_WIDTH,2);
      ObjectSetString(0,name,OBJPROP_TEXT,label);
   }
}

bool CaptureSelectedOrder(string kind)
{
   if(OrderSymbol()!=Symbol()) return false;
   int ticket=OrderTicket();
   string key=ShotKey(ticket,kind);
   if(GlobalVariableCheck(key)) return false;
   datetime eventTime=kind=="entry" ? OrderOpenTime():OrderCloseTime();
   string prefix="JournalitTemp_"+IntegerToString(ticket)+"_";
   AddMarker(prefix+"entry",OBJ_ARROW,eventTime,OrderOpenPrice(),
      OrderType()==OP_SELL ? clrTomato:clrLimeGreen,"Entry");
   AddMarker(prefix+"exit",OBJ_ARROW,eventTime,
      kind=="exit" ? OrderClosePrice():0,clrGold,"Exit");
   AddMarker(prefix+"sl",OBJ_HLINE,eventTime,OrderStopLoss(),clrTomato,"SL");
   AddMarker(prefix+"tp",OBJ_HLINE,eventTime,OrderTakeProfit(),
      clrDeepSkyBlue,"TP");
   ChartRedraw();
   string name=ScreenshotName(ticket,kind);
   bool captured=WindowScreenShot("Journalit\\"+name,
      MathMax(320,EffectiveWidth),MathMax(240,EffectiveHeight),-1,-1,
      ALIGN_RIGHT);
   if(captured)
   {
      captured=FileCopy("Journalit\\"+name,0,
         "Journalit\\"+name,FILE_COMMON|FILE_REWRITE);
      FileDelete("Journalit\\"+name);
   }
   ObjectDelete(0,prefix+"entry"); ObjectDelete(0,prefix+"exit");
   ObjectDelete(0,prefix+"sl"); ObjectDelete(0,prefix+"tp"); ChartRedraw();
   if(captured) GlobalVariableSet(key,(double)TimeCurrent());
   return captured;
}

void CaptureTrades()
{
   if(EffectiveCaptureEntry)
      for(int i=0;i<OrdersTotal();i++)
         if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES) &&
            IsMarketOrder(OrderType())) CaptureSelectedOrder("entry");
   if(EffectiveCaptureExit)
      for(int i=OrdersHistoryTotal()-1;i>=0;i--)
         if(OrderSelect(i,SELECT_BY_POS,MODE_HISTORY) &&
            IsMarketOrder(OrderType()) && OrderCloseTime()>=ExpertStartedAt)
            CaptureSelectedOrder("exit");
}

int WriteSelectedOrder(int handle,string status)
{
   if(!IsMarketOrder(OrderType())) return 0;
   datetime closeTime=status=="CLOSED" ? OrderCloseTime():0;
   FileWrite(handle,"TRADE","MT4",IntegerToString(OrderTicket()),
      CleanText(OrderSymbol()),DirectionForType(OrderType()),status,
      Int64ToString((long)OrderOpenTime()),Int64ToString((long)closeTime),
      DoubleToString(OrderLots(),8),DoubleToString(OrderOpenPrice(),10),
      status=="CLOSED" ? DoubleToString(OrderClosePrice(),10):"",
      OrderStopLoss()>0 ? DoubleToString(OrderStopLoss(),10):"",
      OrderTakeProfit()>0 ? DoubleToString(OrderTakeProfit(),10):"",
      DoubleToString(OrderProfit(),8),DoubleToString(OrderCommission(),8),
      DoubleToString(OrderSwap(),8),IntegerToString(OrderMagicNumber()),
      CleanText(OrderComment()));
   return 1;
}

int WriteScreenshotEvents(int handle)
{
   int count=0;
   for(int pool=0;pool<2;pool++)
   {
      int total=pool==0 ? OrdersTotal():OrdersHistoryTotal();
      int mode=pool==0 ? MODE_TRADES:MODE_HISTORY;
      for(int i=0;i<total;i++)
      {
         if(!OrderSelect(i,SELECT_BY_POS,mode) || !IsMarketOrder(OrderType()))
            continue;
         if(OrderSymbol()!=Symbol()) continue;
         for(int k=0;k<2;k++)
         {
            string kind=k==0 ? "entry":"exit";
            string key=ShotKey(OrderTicket(),kind);
            string name=ScreenshotName(OrderTicket(),kind);
            if(!GlobalVariableCheck(key) ||
               !FileIsExist("Journalit\\"+name,FILE_COMMON)) continue;
            FileWrite(handle,"SCREENSHOT",IntegerToString(OrderTicket()),kind,
               name,Int64ToString((long)GlobalVariableGet(key)),
               CleanText(OrderSymbol()),TimeframeName());
            count++;
         }
      }
   }
   return count;
}

void ExportSnapshot()
{
   int handle=FileOpen(SnapshotFileName(),
      FILE_WRITE|FILE_CSV|FILE_COMMON|FILE_ANSI,'\t');
   if(handle==INVALID_HANDLE)
   {
      Print("JournalitMT4: cannot write snapshot. Error ",GetLastError());
      return;
   }
   FileWriteString(handle,"JOURNALIT_MT_SNAPSHOT_V2\r\n");
   FileWrite(handle,"ACCOUNT","MT4",IntegerToString(AccountNumber()),
      CleanText(AccountServer()),CleanText(AccountCurrency()),
      DoubleToString(AccountBalance(),8),DoubleToString(AccountEquity(),8),
      DoubleToString(AccountProfit(),8),DoubleToString(AccountMargin(),8),
      DoubleToString(AccountFreeMargin(),8),
      DoubleToString(AccountMargin()>0 ?
         AccountEquity()/AccountMargin()*100.0:0,8),
      DoubleToString(AccountCredit(),8),IntegerToString(AccountLeverage()),
      CleanText(AccountCompany()),CleanText(AccountName()),AccountMode(),"","",
      Int64ToString((long)TimeCurrent()));
   int trades=0;
   for(int i=0;i<OrdersTotal();i++)
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES))
         trades+=WriteSelectedOrder(handle,"OPEN");
   for(int i=0;i<OrdersHistoryTotal();i++)
      if(OrderSelect(i,SELECT_BY_POS,MODE_HISTORY))
         trades+=WriteSelectedOrder(handle,"CLOSED");
   int screenshots=WriteScreenshotEvents(handle);
   FileWrite(handle,"END",IntegerToString(trades),
      IntegerToString(screenshots));
   FileFlush(handle); FileClose(handle);
}

void RunCycle() { LoadJournalitSettings(); CaptureTrades(); ExportSnapshot(); }
int OnInit()
{
   FolderCreate("Journalit");
   FolderCreate("Journalit",FILE_COMMON);
   ExpertStartedAt=TimeCurrent();
   EventSetTimer(MathMax(1,ExportIntervalSeconds));
   RunCycle();
   Print("JournalitMT4 local exporter started. No login or password is used.");
   return INIT_SUCCEEDED;
}
void OnTimer() { RunCycle(); }
void OnDeinit(const int reason) { EventKillTimer(); }
