#property strict
#property version   "2.00"
#property description "Journalit private local trade, account and chart exporter for MetaTrader 5"

input int  ExportIntervalSeconds = 5;
input bool CaptureEntryScreenshots = true;
input bool CaptureExitScreenshots = true;
input int  ScreenshotWidth = 1600;
input int  ScreenshotHeight = 900;
input bool ShowTradeMarkers = true;

datetime ExpertStartedAt = 0;
bool EffectiveCaptureEntry = true;
bool EffectiveCaptureExit = true;
bool EffectiveShowMarkers = true;
int EffectiveWidth = 1600;
int EffectiveHeight = 900;

string Int64ToString(long value) { return StringFormat("%I64d", value); }

string CleanText(string value)
{
   StringReplace(value, "\t", " ");
   StringReplace(value, "\r", " ");
   StringReplace(value, "\n", " ");
   return value;
}

string SafeFilePart(string value)
{
   string result = value;
   StringReplace(result, "\\", "_"); StringReplace(result, "/", "_");
   StringReplace(result, ":", "_");  StringReplace(result, "*", "_");
   StringReplace(result, "?", "_");  StringReplace(result, "\"", "_");
   StringReplace(result, "<", "_");  StringReplace(result, ">", "_");
   StringReplace(result, "|", "_");  StringReplace(result, " ", "_");
   return result;
}

string SnapshotFileName()
{
   return "Journalit\\Journalit_MT5_" +
      SafeFilePart(AccountInfoString(ACCOUNT_SERVER)) + "_" +
      Int64ToString((long)AccountInfoInteger(ACCOUNT_LOGIN)) + "_" +
      Int64ToString(ChartID()) + ".tsv";
}

string AccountMode()
{
   ENUM_ACCOUNT_TRADE_MODE mode =
      (ENUM_ACCOUNT_TRADE_MODE)AccountInfoInteger(ACCOUNT_TRADE_MODE);
   if(mode == ACCOUNT_TRADE_MODE_REAL) return "real";
   if(mode == ACCOUNT_TRADE_MODE_CONTEST) return "contest";
   return "demo";
}

string TimeframeName()
{
   return EnumToString((ENUM_TIMEFRAMES)Period());
}

void LoadJournalitSettings()
{
   EffectiveCaptureEntry=CaptureEntryScreenshots;
   EffectiveCaptureExit=CaptureExitScreenshots;
   EffectiveWidth=ScreenshotWidth;
   EffectiveHeight=ScreenshotHeight;
   EffectiveShowMarkers=ShowTradeMarkers;
   int handle=FileOpen("Journalit\\Journalit_settings.tsv",
      FILE_READ|FILE_CSV|FILE_COMMON|FILE_ANSI,'\t');
   if(handle==INVALID_HANDLE) return;
   string header=FileReadString(handle);
   if(header=="JOURNALIT_MT_SETTINGS_V1" && !FileIsEnding(handle))
   {
      string row=FileReadString(handle);
      if(row=="CONFIG")
      {
         EffectiveCaptureEntry=FileReadString(handle)=="1";
         EffectiveCaptureExit=FileReadString(handle)=="1";
         EffectiveWidth=(int)StringToInteger(FileReadString(handle));
         EffectiveHeight=(int)StringToInteger(FileReadString(handle));
         EffectiveShowMarkers=FileReadString(handle)=="1";
      }
   }
   FileClose(handle);
}

string ShotKey(ulong ticket, string kind)
{
   return "JournalitShot5_" +
      Int64ToString((long)AccountInfoInteger(ACCOUNT_LOGIN)) + "_" +
      Int64ToString((long)ticket) + "_" + kind;
}

string ScreenshotName(ulong ticket, string kind)
{
   return "Journalit_MT5_" +
      Int64ToString((long)AccountInfoInteger(ACCOUNT_LOGIN)) + "_" +
      Int64ToString((long)ticket) + "_" + kind + ".png";
}

void AddMarker(string name, ENUM_OBJECT type, datetime markerTime,
   double price, color markerColor, string label)
{
   if(!EffectiveShowMarkers || price <= 0.0) return;
   if(ObjectCreate(0, name, type, 0, markerTime, price))
   {
      ObjectSetInteger(0, name, OBJPROP_COLOR, markerColor);
      ObjectSetInteger(0, name, OBJPROP_WIDTH, 2);
      ObjectSetString(0, name, OBJPROP_TEXT, label);
   }
}

bool CaptureTradeChart(ulong ticket, string kind, string symbol,
   string direction, datetime eventTime, double entryPrice,
   double exitPrice, double stopLoss, double takeProfit)
{
   if(symbol != ChartSymbol()) return false;
   string key = ShotKey(ticket, kind);
   if(GlobalVariableCheck(key)) return false;

   string prefix = "JournalitTemp_" + Int64ToString((long)ticket) + "_";
   AddMarker(prefix + "entry", OBJ_ARROW, eventTime, entryPrice,
      direction == "short" ? clrTomato : clrLimeGreen, "Entry");
   AddMarker(prefix + "exit", OBJ_ARROW, eventTime, exitPrice,
      clrGold, "Exit");
   AddMarker(prefix + "sl", OBJ_HLINE, eventTime, stopLoss,
      clrTomato, "SL");
   AddMarker(prefix + "tp", OBJ_HLINE, eventTime, takeProfit,
      clrDeepSkyBlue, "TP");
   ChartRedraw();

   string fileName = ScreenshotName(ticket, kind);
   bool captured = ChartScreenShot(0, "Journalit\\" + fileName,
      MathMax(320, EffectiveWidth), MathMax(240, EffectiveHeight),
      ALIGN_RIGHT);
   if(captured)
   {
      captured=FileCopy("Journalit\\"+fileName,0,
         "Journalit\\"+fileName,FILE_COMMON|FILE_REWRITE);
      FileDelete("Journalit\\"+fileName);
   }

   ObjectDelete(0, prefix + "entry"); ObjectDelete(0, prefix + "exit");
   ObjectDelete(0, prefix + "sl");    ObjectDelete(0, prefix + "tp");
   ChartRedraw();
   if(captured) GlobalVariableSet(key, (double)TimeCurrent());
   return captured;
}

void CaptureOpenPositions()
{
   if(!EffectiveCaptureEntry) return;
   for(int index = 0; index < PositionsTotal(); index++)
   {
      ulong ticket = PositionGetTicket(index);
      if(ticket == 0) continue;
      string symbol = PositionGetString(POSITION_SYMBOL);
      if(symbol != ChartSymbol()) continue;
      string direction =
         (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE) ==
         POSITION_TYPE_SELL ? "short" : "long";
      CaptureTradeChart(
         (ulong)PositionGetInteger(POSITION_IDENTIFIER), "entry", symbol,
         direction, (datetime)PositionGetInteger(POSITION_TIME),
         PositionGetDouble(POSITION_PRICE_OPEN), 0.0,
         PositionGetDouble(POSITION_SL), PositionGetDouble(POSITION_TP)
      );
   }
}

bool IsTradingDeal(ENUM_DEAL_TYPE dealType)
{
   return dealType == DEAL_TYPE_BUY || dealType == DEAL_TYPE_SELL;
}

bool IsPositionCurrentlyOpen(ulong identifier)
{
   for(int index = 0; index < PositionsTotal(); index++)
   {
      if(PositionGetTicket(index) == 0) continue;
      if((ulong)PositionGetInteger(POSITION_IDENTIFIER) == identifier)
         return true;
   }
   return false;
}

void CaptureRecentClosedPositions()
{
   if(!EffectiveCaptureExit || !HistorySelect(ExpertStartedAt, TimeCurrent()))
      return;
   for(int index = HistoryDealsTotal() - 1; index >= 0; index--)
   {
      ulong deal = HistoryDealGetTicket(index);
      if(deal == 0) continue;
      ENUM_DEAL_ENTRY entry =
         (ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal, DEAL_ENTRY);
      ENUM_DEAL_TYPE type =
         (ENUM_DEAL_TYPE)HistoryDealGetInteger(deal, DEAL_TYPE);
      datetime dealTime =
         (datetime)HistoryDealGetInteger(deal, DEAL_TIME);
      if(!IsTradingDeal(type) || dealTime < ExpertStartedAt ||
         (entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_OUT_BY &&
          entry != DEAL_ENTRY_INOUT))
         continue;
      ulong identifier =
         (ulong)HistoryDealGetInteger(deal, DEAL_POSITION_ID);
      if(IsPositionCurrentlyOpen(identifier)) continue;
      string symbol = HistoryDealGetString(deal, DEAL_SYMBOL);
      CaptureTradeChart(identifier, "exit", symbol,
         type == DEAL_TYPE_BUY ? "short" : "long", dealTime, 0.0,
         HistoryDealGetDouble(deal, DEAL_PRICE), 0.0, 0.0);
   }
}

bool ContainsIdentifier(const ulong &identifiers[], ulong identifier)
{
   for(int index = 0; index < ArraySize(identifiers); index++)
      if(identifiers[index] == identifier) return true;
   return false;
}

void AddIdentifier(ulong &identifiers[], ulong identifier)
{
   if(identifier == 0 || ContainsIdentifier(identifiers, identifier)) return;
   int next = ArraySize(identifiers);
   ArrayResize(identifiers, next + 1);
   identifiers[next] = identifier;
}

int WriteOpenPositions(int handle)
{
   int count = 0;
   for(int index = 0; index < PositionsTotal(); index++)
   {
      if(PositionGetTicket(index) == 0) continue;
      ulong identifier = (ulong)PositionGetInteger(POSITION_IDENTIFIER);
      string direction =
         (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE) ==
         POSITION_TYPE_SELL ? "short" : "long";
      FileWrite(handle, "TRADE", "MT5", Int64ToString((long)identifier),
         CleanText(PositionGetString(POSITION_SYMBOL)), direction, "OPEN",
         Int64ToString(PositionGetInteger(POSITION_TIME)), "0",
         DoubleToString(PositionGetDouble(POSITION_VOLUME), 8),
         DoubleToString(PositionGetDouble(POSITION_PRICE_OPEN), 10), "",
         PositionGetDouble(POSITION_SL) > 0.0 ?
            DoubleToString(PositionGetDouble(POSITION_SL), 10) : "",
         PositionGetDouble(POSITION_TP) > 0.0 ?
            DoubleToString(PositionGetDouble(POSITION_TP), 10) : "",
         DoubleToString(PositionGetDouble(POSITION_PROFIT), 8), "0",
         DoubleToString(PositionGetDouble(POSITION_SWAP), 8),
         Int64ToString(PositionGetInteger(POSITION_MAGIC)),
         CleanText(PositionGetString(POSITION_COMMENT)));
      count++;
   }
   return count;
}

int WriteClosedPosition(int handle, ulong identifier)
{
   if(IsPositionCurrentlyOpen(identifier)) return 0;
   int total = HistoryDealsTotal();
   double entryVolume=0, exitVolume=0, entryNotional=0, exitNotional=0;
   double profit=0, commission=0, swap=0;
   datetime openTime=0, closeTime=0;
   string symbol="", comment="", direction="long";
   long magic=0; bool directionKnown=false;
   for(int index=0; index<total; index++)
   {
      ulong deal=HistoryDealGetTicket(index);
      if(deal==0 ||
         (ulong)HistoryDealGetInteger(deal, DEAL_POSITION_ID)!=identifier)
         continue;
      ENUM_DEAL_TYPE type =
         (ENUM_DEAL_TYPE)HistoryDealGetInteger(deal, DEAL_TYPE);
      ENUM_DEAL_ENTRY entry =
         (ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal, DEAL_ENTRY);
      double volume=HistoryDealGetDouble(deal, DEAL_VOLUME);
      double price=HistoryDealGetDouble(deal, DEAL_PRICE);
      datetime time=(datetime)HistoryDealGetInteger(deal, DEAL_TIME);
      profit+=HistoryDealGetDouble(deal, DEAL_PROFIT);
      commission+=HistoryDealGetDouble(deal, DEAL_COMMISSION);
      swap+=HistoryDealGetDouble(deal, DEAL_SWAP);
      if(!IsTradingDeal(type)) continue;
      if(symbol=="") symbol=HistoryDealGetString(deal, DEAL_SYMBOL);
      if(comment=="") comment=HistoryDealGetString(deal, DEAL_COMMENT);
      magic=HistoryDealGetInteger(deal, DEAL_MAGIC);
      if(entry==DEAL_ENTRY_IN || entry==DEAL_ENTRY_INOUT)
      {
         entryVolume+=volume; entryNotional+=volume*price;
         if(openTime==0 || time<openTime) openTime=time;
         if(!directionKnown)
         {
            direction=type==DEAL_TYPE_SELL ? "short" : "long";
            directionKnown=true;
         }
      }
      if(entry==DEAL_ENTRY_OUT || entry==DEAL_ENTRY_OUT_BY ||
         entry==DEAL_ENTRY_INOUT)
      {
         exitVolume+=volume; exitNotional+=volume*price;
         if(time>closeTime) closeTime=time;
      }
   }
   if(entryVolume<=0 || exitVolume+0.00000001<entryVolume ||
      openTime==0 || closeTime==0 || symbol=="") return 0;
   FileWrite(handle, "TRADE", "MT5", Int64ToString((long)identifier),
      CleanText(symbol), direction, "CLOSED",
      Int64ToString((long)openTime), Int64ToString((long)closeTime),
      DoubleToString(entryVolume,8),
      DoubleToString(entryNotional/entryVolume,10),
      DoubleToString(exitNotional/exitVolume,10), "", "",
      DoubleToString(profit,8), DoubleToString(commission,8),
      DoubleToString(swap,8), Int64ToString(magic), CleanText(comment));
   return 1;
}

int WriteClosedPositions(int handle)
{
   if(!HistorySelect(0, TimeCurrent())) return 0;
   ulong identifiers[];
   for(int index=0; index<HistoryDealsTotal(); index++)
   {
      ulong deal=HistoryDealGetTicket(index);
      if(deal==0) continue;
      ENUM_DEAL_TYPE type =
         (ENUM_DEAL_TYPE)HistoryDealGetInteger(deal, DEAL_TYPE);
      if(IsTradingDeal(type))
         AddIdentifier(identifiers,
            (ulong)HistoryDealGetInteger(deal, DEAL_POSITION_ID));
   }
   int count=0;
   for(int i=0; i<ArraySize(identifiers); i++)
      count+=WriteClosedPosition(handle, identifiers[i]);
   return count;
}

int WriteScreenshotEvents(int handle)
{
   int count=0;
   if(!HistorySelect(0, TimeCurrent())) return 0;
   ulong identifiers[];
   for(int index=0; index<HistoryDealsTotal(); index++)
   {
      ulong deal=HistoryDealGetTicket(index);
      if(deal!=0)
         AddIdentifier(identifiers,
            (ulong)HistoryDealGetInteger(deal, DEAL_POSITION_ID));
   }
   for(int p=0; p<PositionsTotal(); p++)
   {
      if(PositionGetTicket(p)!=0)
         AddIdentifier(identifiers,
            (ulong)PositionGetInteger(POSITION_IDENTIFIER));
   }
   for(int i=0; i<ArraySize(identifiers); i++)
   {
      string eventSymbol="";
      for(int p=0; p<PositionsTotal(); p++)
         if(PositionGetTicket(p)!=0 &&
            (ulong)PositionGetInteger(POSITION_IDENTIFIER)==identifiers[i])
         {
            eventSymbol=PositionGetString(POSITION_SYMBOL);
            break;
         }
      if(eventSymbol=="")
         for(int d=0; d<HistoryDealsTotal(); d++)
         {
            ulong deal=HistoryDealGetTicket(d);
            if(deal!=0 &&
               (ulong)HistoryDealGetInteger(deal,DEAL_POSITION_ID)==identifiers[i])
            {
               eventSymbol=HistoryDealGetString(deal,DEAL_SYMBOL);
               if(eventSymbol!="") break;
            }
         }
      if(eventSymbol!=ChartSymbol()) continue;
      for(int k=0; k<2; k++)
      {
         string kind=k==0 ? "entry" : "exit";
         string key=ShotKey(identifiers[i], kind);
         string name=ScreenshotName(identifiers[i], kind);
         if(!GlobalVariableCheck(key) ||
            !FileIsExist("Journalit\\"+name, FILE_COMMON)) continue;
         FileWrite(handle, "SCREENSHOT",
            Int64ToString((long)identifiers[i]), kind, name,
            Int64ToString((long)GlobalVariableGet(key)),
            CleanText(eventSymbol), TimeframeName());
         count++;
      }
   }
   return count;
}

void ExportSnapshot()
{
   int handle=FileOpen(SnapshotFileName(),
      FILE_WRITE|FILE_CSV|FILE_COMMON|FILE_ANSI, '\t');
   if(handle==INVALID_HANDLE)
   {
      Print("JournalitMT5: cannot write snapshot. Error ",GetLastError());
      return;
   }
   FileWriteString(handle,"JOURNALIT_MT_SNAPSHOT_V2\r\n");
   FileWrite(handle,"ACCOUNT","MT5",
      Int64ToString((long)AccountInfoInteger(ACCOUNT_LOGIN)),
      CleanText(AccountInfoString(ACCOUNT_SERVER)),
      CleanText(AccountInfoString(ACCOUNT_CURRENCY)),
      DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE),8),
      DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY),8),
      DoubleToString(AccountInfoDouble(ACCOUNT_PROFIT),8),
      DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN),8),
      DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE),8),
      DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL),8),
      DoubleToString(AccountInfoDouble(ACCOUNT_CREDIT),8),
      Int64ToString((long)AccountInfoInteger(ACCOUNT_LEVERAGE)),
      CleanText(AccountInfoString(ACCOUNT_COMPANY)),
      CleanText(AccountInfoString(ACCOUNT_NAME)), AccountMode(), "", "",
      Int64ToString((long)TimeCurrent()));
   int trades=WriteOpenPositions(handle)+WriteClosedPositions(handle);
   int screenshots=WriteScreenshotEvents(handle);
   FileWrite(handle,"END",IntegerToString(trades),
      IntegerToString(screenshots));
   FileFlush(handle); FileClose(handle);
}

void RunCycle()
{
   LoadJournalitSettings();
   CaptureOpenPositions();
   CaptureRecentClosedPositions();
   ExportSnapshot();
}

int OnInit()
{
   FolderCreate("Journalit");
   FolderCreate("Journalit",FILE_COMMON);
   ExpertStartedAt=TimeCurrent();
   EventSetTimer(MathMax(1,ExportIntervalSeconds));
   RunCycle();
   Print("JournalitMT5 local exporter started. No login or password is used.");
   return INIT_SUCCEEDED;
}

void OnTimer() { RunCycle(); }
void OnDeinit(const int reason) { EventKillTimer(); }
