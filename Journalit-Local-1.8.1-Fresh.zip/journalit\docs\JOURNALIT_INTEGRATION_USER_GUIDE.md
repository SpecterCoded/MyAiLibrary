---
title: Journalit User Guide
pluginId: journalit
pluginVersion: 1.8.1
minimumObsidianVersion: 1.12.4
desktopOnly: true
---

# Journalit user guide

Journalit is a desktop trading journal for Obsidian. It creates normal Markdown
trade notes inside the user's vault and turns those notes into dashboards,
reviews, setup statistics, account tracking, and searchable trade history.

This build also includes a local MetaTrader 4 and MetaTrader 5 integration. The
MetaTrader Experts can import account state, open positions, closed history, and
entry/exit chart screenshots without a Journalit login, subscription, FTP
account, or hosted Journalit service.

## Important facts

- Journalit works only in the Obsidian desktop application.
- Minimum supported Obsidian version: 1.12.4.
- The plugin ID and folder name are `journalit`.
- The default journal folder is `!Journalit`.
- Trade notes remain readable Markdown files even when the plugin is disabled.
- Journal data, Trade Import, Quick Import, account discovery, synchronization,
  and screenshots are processed locally. The production plugin contains no
  Journalit login, subscription, FTP, entitlement, or hosted-sync endpoint.
- Local MetaTrader import never reads or stores trading passwords, investor
  passwords, Journalit credentials, or authentication tokens.
- Accounts in different currencies remain separate. Journalit does not contact
  an online exchange-rate service to manufacture a combined total.
- Journalit is a journal and analytics tool. It does not place, modify, or close
  trades.
- Back up the entire Obsidian vault before moving the journal folder, replacing
  the plugin, or testing a new release.

## Quick start

1. Install Journalit in the Obsidian vault.
2. Enable **Journalit** under **Settings → Community plugins**.
3. Complete the onboarding screens.
4. Open **Journalit → Settings → General** and select the base currency, date
   format, and journal folder.
5. Create at least one account in **Account Dashboard**, or install a local
   MetaTrader Expert and let Journalit detect the account automatically.
6. Add a test trade with **Add Trade**.
7. Open **Trade Log** and confirm the trade appears.
8. Open **Trading Dashboard** and select a period and account to see analytics.
9. Create the daily and weekly reviews that fit the trading routine.

## Install Journalit manually

### From a release ZIP

The release ZIP should contain a top-level folder named `journalit`. At minimum,
that folder must contain:

```text
journalit/
  main.js
  manifest.json
  styles.css
```

This build should also include:

```text
journalit/
  metatrader/
    JournalitMT4.mq4
    JournalitMT5.mq5
    JournalitMT5.ex5
    README.md
```

Installation steps:

1. Close Obsidian.
2. Open the vault folder in File Explorer.
3. Open `.obsidian/plugins`.
4. Copy the complete `journalit` folder into that directory.
5. The final path must be
   `<vault>/.obsidian/plugins/journalit/manifest.json`, not a double nested
   `journalit/journalit/manifest.json`.
6. Reopen Obsidian.
7. Open **Settings → Community plugins**.
8. Select **Reload plugins** if Journalit is not listed.
9. Enable **Journalit**.

If Obsidian is running while plugin files are replaced, disable and re-enable
Journalit or fully restart Obsidian.

## First-time configuration

### General

Set the following first:

- **Base currency** controls the currency used by general totals.
- **Display name** personalizes headings and review copy.
- **Home startup behavior** decides whether Home opens always, only when no
  other file is open, or never automatically.
- **Navigation behavior** decides whether Journalit pages replace the current
  tab or open in a new tab.
- **Privacy mode** masks sensitive values while sharing the screen.
- **Journal folder** changes where Journalit stores its notes. The default is
  `!Journalit`.

### Trading

Review these settings before importing real history:

- Date and 12/24-hour time formats.
- Week start and weekend handling.
- Analytics date basis: entry date or exit/realized date.
- Trading-day cutoff time for sessions that pass midnight.
- Direct P&L or dollar-value input preferences.
- Break-even thresholds.
- Default risk and R-multiple display.
- MAE/MFE input mode.
- Whether a newly created trade opens automatically.

### Journal Setup

Journal Setup has three areas:

- **Reviews** configures daily, weekly, monthly, quarterly, and yearly review
  templates, checklists, and goals.
- **Customization** configures tickers, symbol mappings, setups, mistakes, tags,
  events, and custom fields.
- **Session Mode** configures trading sessions, preparation, trade gates,
  resources, and phase layouts.

### Sync

The Sync page contains the local MetaTrader controls:

- Detected accounts and connection status.
- Local shared-folder path and importer diagnostics.
- Entry and exit screenshot switches.
- Screenshot width and height.
- Screenshot marker visibility.
- Removal of temporary terminal images after a successful vault copy.
- Optional full Account Pulse on Trading Dashboard.
- Manual **Import now** action.

The dependable login-free synchronization method in this build is **Local
MetaTrader**.

### Advanced

Use Advanced for maintenance:

- Change or repair the Journalit folder.
- Repair image paths after manually moving files.
- Export settings before a reset or update.
- Import settings into a compatible installation.
- Reset plugin settings when troubleshooting.

Resetting settings is not the same as deleting trade notes. Always read a
confirmation dialog carefully and make a vault backup first.

## Navigation and search

The Journalit sidebar is the main navigation surface. It contains:

### Overview

- **Home**
- **Trading Dashboard**
- **Trade Log**
- **Setups**
- **Account Dashboard**

### Reviews

- **Today's DRC**
- **This Week's Review**
- **This Month's Review**
- **This Quarter's Review**
- **This Year's Review**

### Tools

- **Add Trade**
- **Layout Builder**
- **Quick Import**
- **Trade Import**
- **Position Size Calculator**
- **Session Mode**

Use the sidebar search field to find trades and reviews. Sidebar items can be
reordered or hidden in the navigation configuration. Hiding an item does not
delete its data.

## Recommended everyday workflow

### Before trading

1. Open **Session Mode**.
2. Complete preparation resources, goals, and the checklist.
3. Use the **Trade Gate** to record whether conditions give a green light,
   require waiting, or mean no trade.
4. Confirm account risk with **Position Size Calculator**.

### During trading

1. Keep MetaTrader running if automatic import is enabled.
2. Keep the Expert attached to every symbol chart that may be traded if chart
   screenshots are required.
3. Journal context manually: thesis, setup, emotion, mistake, tags, and notes.
4. Add extra images by drag-and-drop, clipboard paste, or file selection.

### After trading

1. Confirm the closed trade updated in **Trade Log**.
2. Open the trade from the close notification.
3. Review automatic entry/exit screenshots.
4. Add lessons and annotations.
5. Mark the trade reviewed.
6. Complete **Today's DRC**.

### End of week/month/quarter/year

Open the corresponding review page. Journalit summarizes eligible trade notes
and provides configured review widgets, goals, and questions.

## Home

Home is a configurable overview, not a separate data source. Its values come
from trade notes, account metadata, reviews, and local MetaTrader state.

Home supports:

- Period, account, and trade-type filters.
- Dragging and resizing widgets in edit mode.
- Quick links to common pages.
- Compact Account Pulse when a MetaTrader account has been detected.
- A full Account Pulse widget by default.

Available Home widgets include:

- Recent Items
- Year Heatmap
- Getting Started
- Weekly Summary
- Position Size
- Embedded Note
- Current Streak
- Best Hours
- Setup Leaderboard
- Unreviewed Trades
- Goals Progress
- Trading Score
- Assets Under Management
- Drawdown Monitor
- Profit Target

If a Home number looks wrong, first check the selected period, selected account,
trade type, trade status, and analytics date basis.

## Trading Dashboard

Trading Dashboard reads the current Trade Log notes and calculates performance
for the active filters. An older trade is included when its Markdown note uses a
compatible Journalit trade schema and is inside a recognized trades folder.

Metrics can include:

- Net P&L.
- Win rate.
- Profit factor.
- Sharpe ratio.
- Expectancy.
- Maximum drawdown.
- Best day.
- Largest win and largest loss.
- Longest win and loss streaks.
- Trade, win, and loss counts.
- Average win and average loss.
- Average reward-to-risk and risk-based R.
- Average holding time.
- Time in drawdown and recovery metrics.
- MAE and MFE metrics when those values exist.

Dashboard widgets include:

- Cumulative P&L.
- Long and short P&L.
- Performance calendar.
- Daily performance.
- Trade count chart.
- Weekday and hourly performance.
- Total, long, and short drawdown.
- Recent trades.
- Rolling win/loss ratio.
- Rolling average win/loss.
- Optional full MetaTrader Account Pulse.

Use dashboard edit mode to arrange visible widgets. Filters affect the
calculated result but do not alter trade notes.

## Trade Log

Trade Log is the database view of all recognized Journalit trade notes. It is
not a second copy of the trades.

Common columns include:

- Image.
- Account.
- Ticker/symbol.
- Status.
- Net P&L.
- Direction.
- Setups.
- Mistakes.
- Tags.
- Open date.
- Reviewed state.

Optional columns can show timing, prices, risk, position values, and custom
fields. Users can sort, filter, expand rows, select multiple trades, and perform
batch actions.

Trade Log also has an image gallery. The gallery can separate automatic and
manual images, group images by trade, and change sorting.

Deleting a row or trade note can affect all dashboards and reviews. Prefer
Obsidian's trash so accidental deletion remains recoverable.

## Add and edit a trade

Supported asset types include stocks, options, futures, forex, crypto, and CFDs.
The form changes available fields according to the asset type and configured
layout.

Possible form sections include:

- Asset-specific fields.
- Account, symbol, direction, size, entry, and exit.
- Commission, rebate, swap, and other fees.
- Stop loss and planned risk.
- One or more take-profit levels.
- Ideal exits.
- MAE and MFE.
- P&L preview and realized P&L.
- Setup and mistake.
- Tags and events.
- Thesis and journal text.
- Attachments.
- Custom fields.

The **Layout Builder** controls which form sections appear and their order. A
hidden field is not necessarily deleted from an existing note; it may simply be
hidden from the normal form.

### Manual journaling is protected

Local MetaTrader synchronization updates broker-owned trade facts such as
status, prices, times, ticket, direction, costs, and P&L. It must not overwrite
user-managed content:

- Journal text.
- Thesis.
- Tags.
- Setups and mistakes selected by the user.
- Emotions and lessons.
- Image annotations.
- Manual images.
- Other manually maintained review content.

## Images

### Manual images

Manual images are unlimited and remain user-managed. Users can:

- Drag and drop files.
- Paste from the clipboard.
- Select a file.
- Add or edit annotations.

### Automatic MetaTrader screenshots

The first local release supports one automatic entry screenshot and one
automatic exit screenshot per trade.

The Expert captures the **MetaTrader chart only**. It does not capture the
desktop, browser, YouTube, passwords, or other open windows.

For accurate symbol, timeframe, template, and indicator screenshots:

- Attach the Expert to every chart that may be traded.
- Keep MetaTrader running.
- Enable AutoTrading in MT4 or Algo Trading in MT5.
- Do not let the computer sleep at the entry or exit event.

The Expert briefly draws entry, exit, SL, TP, direction, ticket, and P&L
markers, captures the chart, and removes its temporary objects. Existing chart
objects are not intentionally changed.

Historical closed trades can be imported, but old entry and exit screenshots
cannot be recreated after the event. Screenshot capture applies to new events
while the Expert is running.

Automatic files are copied into:

```text
Journalit/Automatic Trade Images
```

Automatic screenshot metadata is stored separately from the trade's manual
`images` field, so synchronization and duplicate checks do not replace manual
uploads.

## Setups

Setups are reusable trading playbooks. A setup can contain rules and descriptive
context and can be assigned to many trades.

The Setups area provides:

- Setup overview cards.
- Setup performance.
- Pairs view.
- Comparison of selected setups.
- Individual setup pages with linked trades and statistics.

Setup statistics come from trades assigned to that setup. Renaming or changing
a setup should be done through Journalit so references remain consistent.

## Account Dashboard

Account Dashboard combines manually configured trading-account metadata with
current local MetaTrader account state.

Users can create accounts manually with:

- Account name and currency.
- Initial balance.
- Demo, evaluation, funded, real, or custom account type.
- Fixed, end-of-day trailing, manual, or no drawdown model.
- Absolute or percentage profit targets.
- Monthly costs.
- Deposit and withdrawal records.
- Copy-account configuration and multipliers where applicable.

Account views can show:

- Balance and equity.
- Floating P&L.
- Margin and free margin.
- Margin level.
- Credit.
- Leverage.
- Deposits and withdrawals.
- Growth and assets under management.
- Drawdown and profit-target progress.
- Linked trades.

Do not combine balances from accounts with different currencies as if they were
one value. Journalit deliberately shows those accounts separately unless the
user has supplied a trustworthy conversion method elsewhere.

## Account Pulse

Account Pulse is the reusable live MetaTrader widget. A compact pulse appears
after at least one account has been detected on:

- Home.
- Trading Dashboard.
- Trade Log.
- Account Dashboard.
- Individual account pages.

Home and Account Dashboard also provide a full version. The full Trading
Dashboard version is optional in Sync settings.

Connection state is based on the age of the last valid local snapshot:

- **Connected:** updated within 15 seconds.
- **Stale:** older than 15 seconds but no older than 2 minutes.
- **Disconnected:** no update for more than 2 minutes.

Live values are kept in memory. One-minute account history is retained for 30
days in the plugin cache. Daily balance/equity summaries are retained in account
metadata without the 30-day limit.

Account numbers are masked by default. Users may reveal or mask an account,
rename its display name, and override its detected type to Evaluation or Funded.

### Disconnect versus forget

- **Disconnect** stops processing the detected connection but keeps its
  metadata.
- **Forget** removes the local connection metadata and detailed live history.
- Neither action should delete existing Trade Log notes or the user's manual
  journal content.

## Local MetaTrader 4 installation

1. In MT4 select **File → Open Data Folder**.
2. Open `MQL4/Experts`.
3. Copy `metatrader/JournalitMT4.mq4` into that folder.
4. Open MetaEditor 4.
5. Compile `JournalitMT4.mq4`.
6. Return to MT4 and refresh the Navigator if required.
7. Attach **JournalitMT4** to every chart that may be traded.
8. Enable **AutoTrading**.
9. Keep MT4 and Obsidian desktop running.
10. Open **Journalit Settings → Sync** and confirm the account is detected.

The release provides MT4 source. It must be compiled in the user's own
MetaEditor 4 because MT4 build environments are broker/terminal specific.

## Local MetaTrader 5 installation

1. In MT5 select **File → Open Data Folder**.
2. Open `MQL5/Experts`.
3. Copy `JournalitMT5.ex5`, or copy `JournalitMT5.mq5` and compile it in
   MetaEditor 5.
4. Return to MT5 and refresh the Navigator if required.
5. Attach **JournalitMT5** to every chart that may be traded.
6. Enable **Algo Trading**.
7. Keep MT5 and Obsidian desktop running.
8. Open **Journalit Settings → Sync** and confirm the account is detected.

The included MT5 Expert binary was built from the included source for this
release. Users who prefer source verification can compile the MQ5 file
themselves.

## How local MetaTrader import works

The Experts write local snapshots to:

```text
%APPDATA%\MetaQuotes\Terminal\Common\Files\Journalit
```

Journalit checks that folder approximately every five seconds.

The local flow is:

1. The Expert reads public account and trade state from the logged-in terminal.
2. It writes a complete local snapshot.
3. Journalit validates the snapshot and ignores malformed or incomplete files.
4. Journalit detects or updates the account.
5. Historical closed trades are created once.
6. Open positions update the same note.
7. When a position closes, that same note is updated instead of creating a
   second trade.
8. The closed trade is marked unreviewed.
9. Journalit shows one non-blocking notification with an **Open trade** action.
10. Announced screenshot files are copied into the vault with stable names and
    duplicate detection.

The unique account identity is:

```text
platform + normalized broker server + account login
```

The unique trade identity is:

```text
account identity + ticket or position ID
```

This prevents two brokers from colliding when they use the same ticket number
and prevents Experts attached to several charts from creating duplicate trades.

### Single-account vault isolation

Single-account vault isolation is enabled by default. Because all terminal
installations share the MetaQuotes Common Files folder, every new Obsidian vault
can discover several accounts. Discovery does not import them.

For a private journal per account:

1. Create a fresh Obsidian vault.
2. Install and enable Journalit.
3. Open **Journalit Settings → Sync**.
4. Under **Single-account vault isolation**, select **Use in this vault** beside
   exactly one masked MetaTrader account.
5. Journalit locks the vault to
   `platform + normalized broker server + account login`.
6. Snapshots belonging to every other account are rejected before account
   metadata, trades, balances, history, or screenshots are written.

The lock affects future automatic imports. Changing a lock never silently
deletes existing Trade Log notes. If an older vault already contains mixed
accounts, create a fresh vault for complete historical isolation or explicitly
clean the old notes after making a backup.

Multiple-account mode remains available only as an explicit opt-out for users
who intentionally want combined journals and statistics.

- Switching the logged-in terminal account makes that account available for
  discovery, but a locked vault will reject it unless it matches the lock.
- Running several terminal installations is supported because they share the
  MetaQuotes Common Files folder.
- Demo/Real is detected in MT4.
- Demo/Contest/Real is detected in MT5.
- The user can override the Journalit display type to Prop Evaluation or Funded.
- Passwords and credentials are never exported.

### History and duplicate behavior

- Available closed history is imported even when a trade was opened and closed
  before the Expert was installed.
- Each trade is imported once.
- An open trade becoming closed updates its original note.
- Re-reading an unchanged snapshot does not create another trade, image, or
  close notification.
- Deleting a generated trade note permits it to be created again from the
  retained MetaTrader history on a later import.
- Deleting only dashboard cache does not delete the Markdown trade.

## Reviews

Journalit supports:

- Daily Review / DRC.
- Weekly Review.
- Monthly Review.
- Quarterly Review.
- Yearly Review.

Reviews can be created from navigation or commands. Review settings control
templates, layouts, pre-trade and weekly checklists, recurring daily/weekly
goals, and review-specific custom fields.

The plugin also supports scalper-oriented defaults and session mistake tracking.
When enabled, session outcomes can apply configured mistakes automatically.
Review summaries are only as accurate as the trade dates, accounts, status, and
P&L stored in recognized trade notes.

## Position Size Calculator

The calculator estimates position size from account balance, risk percentage,
entry price, stop loss, optional profit target, and asset class. It supports
stock/crypto, futures, and forex modes.

Always verify contract size, tick value, lot rules, currency conversion, and
broker rounding in the trading platform before placing an order. The calculator
does not send an order to MetaTrader.

## Session Mode

Session Mode organizes a trading session into:

- Waiting.
- Preparation.
- Live.
- Break.
- Ended.

Its configurable modules include preparation resources, goals, checklists,
trade gate, timeline, ended actions, and statistics.

The Trade Gate can record:

- Green light.
- Wait.
- No trade.

Typical gate questions cover setup quality, defined risk, and acceptable market
conditions. Session Mode is a behavioral workflow; it does not block orders in
MetaTrader.

## Layout Builder

Layout Builder controls Journalit forms and review layouts. Use it to:

- Show, hide, and reorder trade sections.
- Arrange review widgets.
- Select a template.
- Create a layout for a particular trading style.

Changing a layout changes presentation and future editing behavior. It does not
automatically erase fields already stored in Markdown notes.

## Customization reference

Users can configure:

- Tickers and symbols.
- Broker symbol mappings, such as symbols with prefixes or suffixes.
- Setups.
- Mistakes.
- Tags.
- Events.
- Custom trade fields.
- Custom review fields.
- Trade form layout.

Symbol mapping is especially important when a broker reports `EURUSD.a` or a
similar symbol but the journal should group it as `EURUSD`.

## Obsidian commands

Journalit commands are available in Obsidian's Command Palette and can be
assigned hotkeys:

- Add Trade.
- Import Trades CSV.
- Quick Import Trades.
- Create/open today's DRC.
- Create/open weekly, monthly, quarterly, and yearly reviews.
- Open Home.
- Open Trading Dashboard.
- Open Trade Log.
- Open Setups.
- Open Account Dashboard.
- Open Navigation Sidebar.
- Open Calendar Sidebar.
- Open Session Mode.
- Open Position Size Calculator.
- Open Layout Builder.
- Switch template.
- Replay onboarding.
- Replay the guide for the current view.
- Open release notes.

Command wording can vary slightly with the selected interface language.

## Local Trade Import and Quick Import

**Trade Import** and **Quick Import** process broker export files entirely
inside Obsidian. They do not require a Journalit login or subscription and do
not upload the file, mappings, preview, or trades to a server.

Supported local formats:

- CSV.
- Delimited TXT.
- XLSX.
- HTML tables and broker HTML statements.

Legacy binary XLS files are not parsed. Open an XLS file in a spreadsheet
application and save it as XLSX or CSV first.

Trade Import provides the full workflow:

1. Select or drop a broker export.
2. Choose the local account and asset type.
3. Let Journalit detect the table, header row, and common trade columns.
4. Correct mappings and date format when necessary.
5. Save the mapping as a reusable local template.
6. Generate a local preview.
7. Review new, changed, invalid, and duplicate rows.
8. Import eligible trades directly into the vault.

Quick Import uses the favorite local template/account or automatic generic
mapping. If a file needs manual mapping, it hands the file and current preview
to the full Trade Import screen.

Local duplicate identity prefers account plus order/ticket ID. When no reliable
order ID exists, Journalit uses account, symbol, direction, entry time, entry
price, and quantity. Reimporting the same file skips unchanged trades. If the
same identified trade changed, such as an open trade becoming closed, Journalit
updates its existing note and preserves manual journal text and images.

## Data storage and backup

Journalit primarily uses ordinary files inside the vault:

- Trade notes are normally under `!Journalit/trades`.
- Reviews and related journal records are under the configured Journalit folder.
- Automatic MetaTrader images are under
  `Journalit/Automatic Trade Images`.
- Plugin settings are stored in
  `.obsidian/plugins/journalit/data.json`.
- Local minute history is stored in
  `.obsidian/plugins/journalit/cache/local-metatrader-history.json`.
- MetaTrader source snapshots are outside the vault in the MetaQuotes Common
  Files folder.

Back up:

1. The complete configured Journalit journal folder.
2. The automatic and manual image folders.
3. `.obsidian/plugins/journalit/data.json`.
4. Any custom templates or linked resources.

Do not publish `data.json`, cache files, local snapshots, account history, or
user trade notes in a public plugin release.

## Updating Journalit

1. Back up the vault.
2. Export Journalit settings.
3. Close Obsidian.
4. Keep `data.json` and the user's journal files.
5. Replace only the release-owned plugin files.
6. Reopen Obsidian and enable Journalit.
7. Confirm the version in `manifest.json`.
8. Test Home, Trade Log, one dashboard, one review, and Sync.
9. Run **Import now** and verify that an existing trade is not duplicated.

Never copy a developer update directly over a customized build without first
comparing source changes. Merge the upstream release into a version-controlled
branch, preserve the local MetaTrader changes, rebuild, and run regression
tests.

## Troubleshooting

### Journalit is not visible in Community plugins

- Confirm the exact path is
  `<vault>/.obsidian/plugins/journalit/manifest.json`.
- Confirm `main.js`, `manifest.json`, and `styles.css` are present.
- Restart Obsidian or select Reload plugins.
- Confirm Restricted Mode is not blocking community plugins.

### The layout looks unstyled or broken

- Confirm the release `styles.css` matches `main.js`.
- Do not mix files from different plugin versions.
- Disable Journalit, replace all three runtime files from one release, restart
  Obsidian, and enable it again.
- Test with custom CSS snippets disabled.

### MetaTrader account is not detected

- Use Obsidian desktop, not mobile.
- Confirm the Expert is attached and AutoTrading/Algo Trading is enabled.
- Confirm MetaTrader is running and logged in.
- Confirm files appear in
  `%APPDATA%\MetaQuotes\Terminal\Common\Files\Journalit`.
- Open Journalit Sync settings and select **Import now**.
- Read importer diagnostics for malformed or incomplete snapshots.
- Wait at least one polling interval.

### Account is Stale or Disconnected

- Bring MetaTrader online.
- Confirm the Expert still appears on the chart.
- Confirm the computer is awake.
- Check MT4/MT5 Experts and Journal logs for errors.
- Confirm security software is not blocking local file writes.

### Trades import but screenshots do not

- Screenshots only exist for new entry/exit events observed by a running Expert.
- Attach the Expert to the chart for the traded symbol.
- Enable entry and exit screenshots in Sync settings.
- Confirm the terminal can create image files in Common Files.
- Confirm the image dimensions are accepted by the terminal.
- Temporarily disable terminal-image cleanup while diagnosing.

### A trade is duplicated

- Compare platform, server, login, and ticket/position ID.
- Check whether old plugin versions created notes without the current
  server-aware identity.
- Do not attach differently named modified Experts that write incompatible
  snapshots.
- Back up the vault before deleting duplicates.
- Keep the correct note if it contains manual journaling; merge user notes before
  trashing another copy.

### Dashboard misses an older trade

- Confirm the trade note is inside a recognized trades folder.
- Confirm its frontmatter is valid and uses the Journalit trade schema.
- Check dashboard period, account, trade type, and date-basis filters.
- Confirm the trade has valid entry/exit time and P&L fields needed by the
  selected metric.
- Reopen the view or restart the plugin to refresh indexes.

### Trade Import or Quick Import cannot read a file

- Confirm the file is CSV, TXT, XLSX, or HTML.
- Convert legacy XLS files to XLSX or CSV.
- Select the correct sheet and one-based header-row number.
- Check required field mappings and the chosen date format.
- Use Direct P&L mode when the export contains realized P&L but does not include
  usable entry price and quantity fields.
- Open the full Trade Import screen when Quick Import reports that mapping needs
  review.

## Privacy and security

Local MetaTrader exports only account/trade data needed by the journal:

- Account identity and broker metadata.
- Account type/mode.
- Balance, equity, floating P&L, margin, free margin, margin level, credit,
  leverage, and currency.
- Open and closed trade history.
- Locally generated chart screenshots when enabled.

The Expert does not need a trading password because it runs inside the terminal
that the user has already logged into. It never exports passwords or tokens.

Users should still protect the vault because it can contain account numbers,
trade history, P&L, notes, and images. Keep account masking enabled when sharing
the screen and encrypt or securely back up sensitive vaults.

## Fixed ChartedByICT links

These links are hardcoded, not user-editable, and should open externally:

- Instagram: <https://instagram.com/ChartedByICT>
- Telegram: <https://t.me/ChartedByICT>
- X: <https://x.com/ChartedByICT>
- YouTube: <https://www.youtube.com/@ChartedByICT>

They appear in General/About settings, onboarding completion, and the sidebar
footer.

## Publishing a download in another project's Integration tab

### Legal requirement

The current repository contains a proprietary source-available license from
Cursivez. It states that copying, modifying, redistributing, hosting, or
creating derivative works is prohibited without explicit written permission.

Do not commit this modified plugin to a public GitHub repository or offer it as
a public download unless the copyright holder has given explicit written
permission or the licensing situation has been replaced with one that grants
those rights. Keep proof of permission with the release records.

The technical publishing steps below apply only after distribution rights are
confirmed.

### Recommended GitHub release

Create a versioned GitHub Release rather than linking to a moving branch ZIP.
Attach a release archive named:

```text
journalit-1.8.1.zip
```

The archive should include only distributable runtime and integration files:

```text
journalit/
  main.js
  manifest.json
  styles.css
  LICENSE
  docs/JOURNALIT_INTEGRATION_USER_GUIDE.md
  metatrader/JournalitMT4.mq4
  metatrader/JournalitMT5.mq5
  metatrader/JournalitMT5.ex5
  metatrader/README.md
```

Never include:

- `data.json`.
- `cache/`.
- `node_modules/`.
- User trade notes or reviews.
- Images.
- MetaTrader snapshots.
- Account history.
- Credentials or tokens.

Publish a SHA-256 checksum beside the ZIP.

### Integration-tab metadata

The main project can keep a small manifest such as:

```json
{
  "id": "journalit",
  "name": "Journalit",
  "version": "1.8.1",
  "minimumObsidianVersion": "1.12.4",
  "desktopOnly": true,
  "downloadUrl": "https://github.com/OWNER/REPOSITORY/releases/download/v1.8.1/journalit-1.8.1.zip",
  "sha256": "REPLACE_WITH_RELEASE_SHA256",
  "guidePath": "docs/JOURNALIT_INTEGRATION_USER_GUIDE.md"
}
```

Replace `OWNER`, `REPOSITORY`, and the checksum with real release values. Do not
hardcode a GitHub URL until the repository and release exist.

The Integration tab should:

1. Show the plugin version and minimum Obsidian version.
2. State that Obsidian desktop is required.
3. Display this guide before installation.
4. Require a user-initiated download.
5. Verify the SHA-256 checksum before extracting.
6. Explain the final plugin folder path.
7. Never overwrite `data.json` or user journal folders.
8. Show separate MT4 and MT5 Expert download/install instructions.
9. Link to a versioned release, not the repository's latest source ZIP.
10. Show release notes and migration warnings before an update.

## Release acceptance checklist

Before calling a build ready:

- Obsidian loads the plugin without console errors.
- Home and sidebar render correctly in light and dark themes.
- A manually added trade appears in Trade Log and Trading Dashboard.
- Existing compatible trade notes appear in analytics.
- MT5 Expert compiles with zero errors and warnings.
- MT4 source compiles in MetaEditor 4.
- A Demo and Real account are detected correctly.
- MT5 Contest detection is tested.
- Evaluation and Funded overrides work.
- Multiple charts do not duplicate trades or screenshots.
- Multiple accounts do not collide.
- Open-to-closed updates one note.
- One close notification appears.
- Manual journal text and images survive synchronization.
- Entry and exit screenshots copy successfully.
- Missing matching chart does not stop trade import.
- Connected, Stale, Disconnected, and recovery states work.
- Minute and daily history retention works.
- Different account currencies remain separate.
- Account masking and reveal work.
- Disconnect and Forget do not delete Trade Log notes.
- All fixed social links open the correct external pages.
- The release ZIP excludes user/private data.
- The ZIP checksum matches.
- The distribution license has been confirmed in writing.
