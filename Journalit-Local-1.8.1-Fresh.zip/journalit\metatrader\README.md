# Journalit local MetaTrader auto import

These Experts export account trade snapshots locally. They do not use FTP,
Journalit servers, authentication, or a subscription.

## MetaTrader 4

1. Open MetaEditor from MT4.
2. Copy `JournalitMT4.mq4` into `MQL4/Experts`.
3. Compile it and attach `JournalitMT4` to every chart you trade.
4. Enable AutoTrading.

## MetaTrader 5

1. Open MetaEditor from MT5.
2. Copy `JournalitMT5.mq5` into `MQL5/Experts`.
3. Compile it and attach `JournalitMT5` to every chart you trade.
4. Enable Algo Trading.

The Experts write one snapshot per chart/account to:

`%APPDATA%\MetaQuotes\Terminal\Common\Files\Journalit`

Journalit watches that folder every five seconds. Multiple chart snapshots are
merged by platform, server, account, and ticket, so they cannot create duplicate
trades. Closed history is imported once, open positions are updated in place,
and a position changing from open to closed updates the existing note.

Entry and exit chart screenshots are enabled by default. The Expert briefly
adds entry/exit/SL/TP markers, captures the chart, then removes the temporary
objects. Journalit copies each image into the vault and keeps automatic images
separate from unlimited manual uploads.

Account numbers are masked in Journalit by default. No Expert ever reads,
exports, or stores an account password, investor credential, token, or Journalit
login.
